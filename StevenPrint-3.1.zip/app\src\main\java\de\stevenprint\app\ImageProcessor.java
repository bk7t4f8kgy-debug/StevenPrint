package de.stevenprint.app;

import android.graphics.Bitmap;
import android.graphics.Color;

/**
 * Deterministic sRGB editing pipeline. Android decodes images into its working
 * colour space; without a usable embedded profile we treat values as sRGB.
 * The same parameter state is applied to preview and print bitmaps.
 */
public final class ImageProcessor {
    private ImageProcessor() { }
    public static Bitmap process(Bitmap source, EditSettings s) {
        int w=source.getWidth(),h=source.getHeight(); int[] input=new int[w*h],out=new int[w*h]; source.getPixels(input,0,w,0,0,w,h);
        float contrast=Math.max(0f,1f+s.contrast/100f), gamma=Math.max(.5f,Math.min(2f,s.gamma/100f));
        float black=Math.max(0,Math.min(100,s.blackPoint))*2.55f, white=255f-Math.max(0,Math.min(100,100-s.whitePoint))*2.55f; if(white<=black)white=black+1;
        float sat=Math.max(0f,1f+s.saturation/100f), temperature=s.temperature*1.2f;
        for(int i=0;i<input.length;i++){int p=input[i];float r=Color.red(p),g=Color.green(p),b=Color.blue(p);
            // Exposure/brightness -> levels -> contrast -> gamma -> saturation -> temperature/RGB.
            r+=s.brightness*2.55f;g+=s.brightness*2.55f;b+=s.brightness*2.55f;
            r=levels(r,black,white);g=levels(g,black,white);b=levels(b,black,white);
            r=(r-128)*contrast+128;g=(g-128)*contrast+128;b=(b-128)*contrast+128;
            r=255f*(float)Math.pow(clamp(r)/255f,1f/gamma);g=255f*(float)Math.pow(clamp(g)/255f,1f/gamma);b=255f*(float)Math.pow(clamp(b)/255f,1f/gamma);
            float l=.2126f*r+.7152f*g+.0722f*b;r=l+(r-l)*sat;g=l+(g-l)*sat;b=l+(b-l)*sat;
            r+=temperature+s.red*2.55f;g+=s.green*2.55f;b+=-temperature+s.blue*2.55f;
            out[i]=Color.argb(Color.alpha(p),clamp(r),clamp(g),clamp(b));
        }
        Bitmap result=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);result.setPixels(out,0,w,0,0,w,h);return s.sharpness>0?sharpen(result,s.sharpness):result;
    }
    private static float levels(float v,float black,float white){return clamp(v,black,white)*255f/(white-black)-black*255f/(white-black);}
    private static Bitmap sharpen(Bitmap source,int amount){int w=source.getWidth(),h=source.getHeight();int[] in=new int[w*h],out=new int[w*h];source.getPixels(in,0,w,0,0,w,h);float a=Math.min(1f,amount/100f);for(int y=0;y<h;y++)for(int x=0;x<w;x++){int i=y*w+x,p=in[i],l=in[y*w+Math.max(0,x-1)],r=in[y*w+Math.min(w-1,x+1)],u=in[Math.max(0,y-1)*w+x],d=in[Math.min(h-1,y+1)*w+x];out[i]=Color.argb(Color.alpha(p),clamp(Color.red(p)+a*(4*Color.red(p)-Color.red(l)-Color.red(r)-Color.red(u)-Color.red(d))),clamp(Color.green(p)+a*(4*Color.green(p)-Color.green(l)-Color.green(r)-Color.green(u)-Color.green(d))),clamp(Color.blue(p)+a*(4*Color.blue(p)-Color.blue(l)-Color.blue(r)-Color.blue(u)-Color.blue(d))));}Bitmap result=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);result.setPixels(out,0,w,0,0,w,h);return result;}
    private static int clamp(float v){return Math.max(0,Math.min(255,Math.round(v)));} private static float clamp(float v,float min,float max){return Math.max(min,Math.min(max,v));}
}
